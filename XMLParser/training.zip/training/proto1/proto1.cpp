// proto1.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
char *cur;
char test1[] = "12.34.56.78";
char test2[] = "1.2.345.6";
char test3[] = "1..3.4";
char test4[] = "1.2.3.4.5.6";

bool is_digit()
{
	if(*cur >= '0' && *cur <= '9')
	{
		return true;
	}
	else
	{
		return false;
	}
}

int match_digit()
{
	if(*cur >= '0' && *cur <= '9')
	{
		int ret = *cur - '0';
		cur++;
		return ret;
	}
	else
	{
		exit(-1);
	}
}

int match_number()
{
	int ret = match_digit();
	if(ret == 0)
	{
		return ret;
	}

	while(is_digit())
	{
		ret *= 10;
		ret += match_digit();
		if(ret > 255)
		{
			exit(-1);
		}

	} 
	return ret;
}

void match_dot()
{
	if(*cur == '.')
	{
		cur++;
		return;
	}
	else 
	{
		exit(-1);
	}
}


void match_end()
{
	if(*cur == '\0')
	{
		return;
	}
	else
	{
		exit(-1);
	}
}


void init_scanner()
{
	cur = test4;
}
void match_ip()
{
	match_number();
	match_dot();
	match_number();
	match_dot();
	match_number();
	match_dot();
	match_number();
	match_end();
	printf("ip match successfully\n");
	getchar();
	
}
int _tmain(int argc, _TCHAR* argv[])
{
	init_scanner();
	match_ip();
	return 0;
}
