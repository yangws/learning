#include <iostream>
#include <stdlib.h>//for atoi()

using namespace std;

bool isValidIP(string ip);

char* test[] = {
	"1a.1b.1c.1d",
	"12.34.56.78",
	"12.0000000003.56.78",
	"1.324.56.78",
	"12.56.78",
	"1.2.3.4.5.6.7",
	".",
	"cocos2d",
	"0.1.2.3",
	"99..8.7",
	".3.4.5.6.7",
	"123"
};
int main(){
	for(int i = 0; i < sizeof(test)/sizeof(test[0]); i ++)
	{
		if(isValidIP(test[i]))
		{
			cout<<test[i]<<" match OK!\n";
		}
		else
		{
			cout<<test[i]<<" match fail!\n";
		}
	}
	getchar(); 
	return 0;
}

bool isValidIP(string ip){
	string delim=".";
	string ret[4];

	string::size_type loc=0,start =0;
	for(int i=0;i<4;i++){
		loc = ip.find(delim, start);
		if(loc != string::npos){
			ret[i]=ip.substr(start,loc-start);
			start=loc+1;
		}else if(i==3){
			ret[i]=ip.substr(start);
		}else{
			//��ʽ���ԣ�Ӧ����3��.
			return false;
		}
	}
	for(int i=0;i<4;i++){
		int num=atoi(ret[i].c_str());
		if(num>255){
			return false;
		}else if((num==0)&&(ret[i].compare("0"))){
			return false;
		}
	}
	return true;
}