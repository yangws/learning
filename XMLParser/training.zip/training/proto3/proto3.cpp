// proto1.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>
#include "proto3.h"


char* test[] = 
{
	"<a>bcd</a>",
	"a><bc>",
	"< a >bcd</a>",
	"<a>bcd</x>"
};

bool check_error(XML_SCANNER* scanner)
{
	if(scanner->err != 0)
	{
		printf("%s match error!!!, error: %s at pos %d \n", scanner->buffer, scanner->err_msg, scanner->cur - scanner->buffer);
		return true;
	}
	else 
	{
		
		return false;
	}
}

void set_error(XML_SCANNER* scanner, int err_no, char* err_msg)
{
	if(scanner->err == 0)
	{
		scanner->err = err_no;
		scanner->err_msg = err_msg;
	}
}

bool scanner_walk(XML_SCANNER* scanner)
{
	if(scanner->err != 0)
	{
		return false;
	}
	else
	{
		scanner->cur++;
		return true;
	}
}

bool xml_match_letter(XML_SCANNER* scanner, char *buf)
{
	char c = *(scanner->cur);
	if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
	{
		bool ret = scanner_walk(scanner);
		*buf = c;
		return ret;
	} 
	else
	{
		*buf = '\0';
		set_error(scanner, ERROR_MATCH_LETTER, "fail to match letter");
		return false;
	}
}

bool xml_match_space(XML_SCANNER* scanner)
{
	bool ret = false;
	while(true) 
	{
		char c = *(scanner->cur);
		if((c == 0x0A) || 
		   (c == 0x0D) || 
	       (c == 0x20) ||
	       (c == 0x09))
	    {
			ret = scanner_walk(scanner);
			if(ret == false)
			{
				return ret;
			}
		}
		else
		{
			return ret;
		}
	}
}

bool xml_match_data(XML_SCANNER* scanner, char *buf)
{
	bool ret = false;
	char *pData = buf;
	while(true)
	{
		char c = *(scanner->cur);
		if((c == '<') || (c == '>') || (c == '&'))
		{
			*pData = '\0';
			return ret;
		}
		else 
		{
			*pData = c;
			pData++;
			ret = scanner_walk(scanner);
			if(ret == false)
			{
				return ret;
			}
		}
	}
}
void xml_match_element_name(XML_SCANNER* scanner, char *name)
{
	char *pData = name;
	xml_match_letter(scanner,pData);
	pData++;
	xml_match_data(scanner, pData);
}

bool xml_match_stag(XML_SCANNER* scanner)
{
	bool ret = false;
	if(*(scanner->cur) == '<')
	{
		ret = scanner_walk(scanner);
		if(ret == false)
		{
			return ret;
		}
	}
	else
	{
		set_error(scanner, ERROR_MATCH_STAG_START, "fail to match stag start '<' ");
		return false;
	}
	scanner->curElement = (char *)malloc(1024);
	xml_match_element_name(scanner, scanner->curElement);
	if(*(scanner->cur) == '>')
	{
		ret = scanner_walk(scanner);
		if(ret == false)
		{
			return false;
		}
	}
	else
	{
		set_error(scanner, ERROR_MATCH_STAG_END, "fail to match stag end  '>' ");
		return false;
	}
}

void xml_match_content(XML_SCANNER* scanner)
{
	char *data = (char *)malloc(8192);
	xml_match_data(scanner, data);
}


void xml_match_etag(XML_SCANNER* scanner)
{
	if(*(scanner->cur) == '<')
	{
		scanner_walk(scanner);
	}
	else
	{
		set_error(scanner, ERROR_MATCH_ETAG_START, "fail to match etag start '<' ");
		return;
	}

	if(*(scanner->cur) == '/')
	{
		scanner_walk(scanner);
	}
	else
	{
		set_error(scanner, ERROR_MATCH_ETAG_START2, "fail to match etag start '/' ");
		return;
	}
	char *element = (char *)malloc(1024);
	xml_match_element_name(scanner, element);

	if(strcmp(element, scanner->curElement) != 0)
	{
		set_error(scanner, ERROR_MATCH_ELEMENT_NAME, "fail to match element name");
		return;
	}

	if(*(scanner->cur) == '>')
	{
		scanner_walk(scanner);
	}
	else
	{
		set_error(scanner, ERROR_MATCH_ETAG_END, "fail to match etag end '>' ");
		return;
	}
}

void xml_match_end(XML_SCANNER* scanner)
{
	if(*(scanner->cur) == '\0')
	{
		return;
	}
	else
	{
		set_error(scanner, ERROR_END, "end not match");
		return;
	}
}

void init_scanner(XML_SCANNER* scanner, char* buffer)
{
	scanner->buffer = buffer;
	scanner->cur = buffer;
	scanner->err = 0;
}

bool match_xml(XML_SCANNER* scanner)
{
	xml_match_stag(scanner);
	xml_match_space(scanner);
	xml_match_content(scanner);
	xml_match_space(scanner);
	xml_match_etag(scanner);
	xml_match_end(scanner);
	if(check_error(scanner))
	{
		return false;
	}
	else
	{
		printf("%s match successfully\n", scanner->buffer);
		return true;
	}
}
int _tmain(int argc, _TCHAR* argv[])
{
	XML_SCANNER *scanner = (XML_SCANNER *)malloc(sizeof(XML_SCANNER));
	for(int i = 0; i < sizeof(test)/sizeof(test[0]); i ++)
	{
		init_scanner(scanner, test[i]);
		match_xml(scanner);
	}
	getchar();
	return 0;
}
