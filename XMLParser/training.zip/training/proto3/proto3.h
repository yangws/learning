#ifndef _PROTO3_H_
#define _PROTO3_H_
typedef struct _xml_scanner{
	char* buffer;
	char* cur;
	char* curElement;
	unsigned int err;
	char *err_msg;
}XML_SCANNER;

#define ERROR_MATCH_STAG_START 1
#define ERROR_MATCH_STAG_END 2
#define ERROR_MATCH_LETTER 3
#define ERROR_END 4
#define ERROR_MATCH_ETAG_START 5
#define ERROR_MATCH_ETAG_START2 6
#define ERROR_MATCH_ELEMENT_NAME 7
#define ERROR_MATCH_ETAG_END 8
#endif