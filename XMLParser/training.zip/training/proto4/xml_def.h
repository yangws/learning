#ifndef _XML_DEF_H_
#define _XML_DEF_H_

struct _xml_element_list;

typedef struct _xml_element{
	char* name;
	char* text;
	_xml_element_list* child_list;
	_xml_element* parent;
}xml_element;
typedef struct _xml_element_list {
	_xml_element* element;
	_xml_element_list* next;
}xml_element_list;

xml_element* xml_build_element(char* name);
void xml_element_add_child(xml_element* parent, xml_element* child);
xml_element* xml_element_get_child(xml_element* parent, char* target_name);
#endif