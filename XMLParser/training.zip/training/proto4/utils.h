#ifndef _UTILS_H
#define _UTILS_H

typedef unsigned char uint8;
typedef unsigned int uint32;

void* ZeroMalloc(int size);
int xml_read_file(char* file_name, char* buffer, uint32* buffersize);

#endif