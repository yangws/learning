#include <string.h>
#include <stdlib.h>
#include <Windows.h>
#include "utils.h"
void* ZeroMalloc(int size)
{
	void* p;
	p = malloc(size);
	if(p)
	{
		memset(p, 0, size);
	}
	return p;
}

int xml_read_file(char* file_name, char* buffer, uint32* buffersize)
{
	HANDLE hFile;
	DWORD dwFileSize, dwBytesRead;

	hFile = CreateFile(file_name,
					   GENERIC_READ,
					   0,
					   NULL,
					   OPEN_EXISTING,
					   FILE_ATTRIBUTE_NORMAL,
					   NULL);

	if (hFile == INVALID_HANDLE_VALUE) 
    { 
        return 0;
    }

    dwFileSize = GetFileSize(hFile, NULL);

	*buffersize = dwFileSize;

	if (dwFileSize == 0)
	{
		goto err;
	}
	if(buffer)
	{
		if(!ReadFile(hFile, buffer, dwFileSize, &dwBytesRead, NULL))
		{
			goto err;
		}
	}

	CloseHandle(hFile);
	return 1;

err:
	CloseHandle(hFile);
	return 0;

}
