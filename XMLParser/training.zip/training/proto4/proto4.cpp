// proto1.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>
#include "proto4.h"
#include "xml_def.h"
#include "utils.h"

bool check_error(XML_SCANNER* scanner)
{
	if(scanner->err != 0)
	{
		//printf("%s match error!!!, error: %s at pos %d \n", scanner->buffer, scanner->err_msg, scanner->cur - scanner->buffer);
		return true;
	}
	else 
	{
		
		return false;
	}
}

void set_error(XML_SCANNER* scanner, int err_no, char* err_msg)
{
	if(scanner->err == 0)
	{
		scanner->err = err_no;
		scanner->err_msg = err_msg;
	}
}

bool scanner_walk(XML_SCANNER* scanner)
{
	if(scanner->err != 0)
	{
		return false;
	}
	else
	{
		char c = *(scanner->cur);
		if(c == 0x0A)
		{
			scanner->line++;
		}
		scanner->cur++;
		return true;
	}
}

bool xml_match_letter(XML_SCANNER* scanner, char *buf)
{
	char c = *(scanner->cur);
	if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
	{
		bool ret = scanner_walk(scanner);
		*buf = c;
		return ret;
	} 
	else
	{
		*buf = '\0';
		set_error(scanner, ERROR_MATCH_LETTER, "fail to match letter");
		return false;
	}
}

bool xml_test_sapce(XML_SCANNER* scanner)
{
	char c = *(scanner->cur);
		if((c == 0x0A) || 
		   (c == 0x0D) || 
	       (c == 0x20) ||
	       (c == 0x09))
		{
			return true;
		}
		else
		{
			return false;
		}
}

bool xml_match_space(XML_SCANNER* scanner)
{
	bool ret = false;
	while(true) 
	{
		if(check_error(scanner))
		{
			return false;
		}
		char c = *(scanner->cur);
		if((c == 0x0A) || 
		   (c == 0x0D) || 
	       (c == 0x20) ||
	       (c == 0x09))
	    {
			ret = scanner_walk(scanner);
			if(ret == false)
			{
				return ret;
			}
		}
		else
		{
			return ret;
		}
	}
}

bool xml_match_data(XML_SCANNER* scanner, char *buf)
{
	bool ret = false;
	char *pData = buf;
	while(true)
	{
		if(check_error(scanner))
		{
			return false;
		}
		char c = *(scanner->cur);
		if((c == '<') || (c == '>') || (c == '&'))
		{
			*pData = '\0';
			return ret;
		}
		else 
		{
			*pData = c;
			pData++;
			ret = scanner_walk(scanner);
			if(ret == false)
			{
				return ret;
			}
		}
	}
}

bool xml_match_data_no_space(XML_SCANNER* scanner, char *buf)
{
	bool ret = false;
	char *pData = buf;
	while(true)
	{
		if(check_error(scanner))
		{
			return false;
		}
		char c = *(scanner->cur);
		if((c == '<') || (c == '>') || (c == '&') || xml_test_sapce(scanner))
		{
			*pData = '\0';
			return ret;
		}
		else 
		{
			*pData = c;
			pData++;
			ret = scanner_walk(scanner);
			if(ret == false)
			{
				return ret;
			}
		}
	}
}

void xml_match_element_name(XML_SCANNER* scanner, char *name)
{
	char *pData = name;
	if(check_error(scanner))
	{
		return;
	}
	xml_match_letter(scanner,pData);
	pData++;
	xml_match_data_no_space(scanner, pData);
}

bool xml_match_stag(XML_SCANNER* scanner)
{
	bool ret = false;
	if(check_error(scanner))
	{
		return false;
	}
	if(*(scanner->cur) == '<')
	{
		ret = scanner_walk(scanner);
		if(ret == false)
		{
			return ret;
		}
	}
	else
	{
		set_error(scanner, ERROR_MATCH_STAG_START, "fail to match stag start '<' ");
		return false;
	}
	
	char* name = (char *)malloc(1024);
	xml_match_element_name(scanner, name);
	xml_element* element = xml_build_element(name);
	xml_match_space(scanner);
	if(*(scanner->cur) == '>')
	{
		ret = scanner_walk(scanner);
		if(ret == false)
		{
			return ret;
		}
	}
	else
	{
		set_error(scanner, ERROR_MATCH_STAG_END, "fail to match stag end  '>' ");
		return false;
	}



	if(scanner->curElement != NULL)
	{
		xml_element_add_child(scanner->curElement, element);
	}

	scanner->curElement = element;

	if(scanner->rootElement == NULL)
	{
		scanner->rootElement = element;
	}

	return true;
}

void xml_match_content(XML_SCANNER* scanner)
{
	while(true)
	{
		if(check_error(scanner))
		{
			return;
		}

		xml_match_space(scanner);

		if(*(scanner->cur) == '\0')
		{
			return;
		}
		if(*(scanner->cur) == '<')
		{
			if(*(scanner->cur + 1) != '/')
			{
				xml_match_element(scanner);
			}
			else 
			{
				return;
			}
		}
		else
		{
			char *data = (char *)ZeroMalloc(8192);
			xml_match_data(scanner, data);
			scanner->curElement->text = data;
			//return;
		}
	}
}


void xml_match_etag(XML_SCANNER* scanner)
{
	if(check_error(scanner))
	{
		return;
	}

	if(*(scanner->cur) == '<')
	{
		scanner_walk(scanner);
	}
	else
	{
		set_error(scanner, ERROR_MATCH_ETAG_START, "fail to match etag start '<' ");
		return;
	}

	

	if(*(scanner->cur) == '/')
	{
		scanner_walk(scanner);
	}
	else
	{
		set_error(scanner, ERROR_MATCH_ETAG_START2, "fail to match etag start '/' ");
		return;
	}
	
	char *element = (char *)malloc(1024);
	xml_match_element_name(scanner, element);

	if(strcmp(element, scanner->curElement->name) != 0)
	{
		set_error(scanner, ERROR_MATCH_ELEMENT_NAME, "fail to match element name");
		return;
	}

	xml_match_space(scanner);

	if(*(scanner->cur) == '>')
	{
		scanner_walk(scanner);
	}
	else
	{
		set_error(scanner, ERROR_MATCH_ETAG_END, "fail to match etag end '>' ");
		return;
	}
	
	scanner->curElement = scanner->curElement->parent;
}

void xml_match_end(XML_SCANNER* scanner)
{
	if(*(scanner->cur) == '\0')
	{
		return;
	}
	else
	{
		set_error(scanner, ERROR_END, "end not match");
		return;
	}
}

void init_scanner(XML_SCANNER* scanner, char* buffer)
{
	scanner->buffer = buffer;
	scanner->cur = buffer;
	scanner->err = 0;
}

bool xml_match_element(XML_SCANNER* scanner)
{
	if(check_error(scanner))
	{
		return false;
	}
	xml_match_stag(scanner);
	xml_match_space(scanner);
	xml_match_content(scanner);
	xml_match_etag(scanner);
	return true;
	
}
int _tmain(int argc, _TCHAR* argv[])
{
	XML_SCANNER *scanner = (XML_SCANNER *)ZeroMalloc(sizeof(XML_SCANNER));
	/*for(int i = 0; i < sizeof(test)/sizeof(test[0]); i ++)
	{
		init_scanner(scanner, test[i]);
		xml_match_element(scanner);
		xml_element* query = xml_element_get_child(scanner->rootElement, "b2");
		if(query != NULL)
		{
			printf("<b2>:%s", query->text);
		}

		//xml_match_end(scanner);
	}*/
	uint32 dwFileSize = 0;
	char* xmlBuffer = NULL;
	xml_read_file("test.xml", NULL, &dwFileSize);

	if(dwFileSize > 0)
	{
		xmlBuffer = (char *)ZeroMalloc(dwFileSize+1);
	}
	int ret;
	if(xmlBuffer != NULL)
	{
		ret = xml_read_file("test.xml", xmlBuffer, &dwFileSize);
	}

	if(ret > 0) 
	{
		init_scanner(scanner, xmlBuffer);
		xml_match_element(scanner);
		if(check_error(scanner))
		{
			printf("%s match error!!!, error: %s at line %d \n", scanner->buffer, scanner->err_msg, scanner->line + 1);
		}
		else 
		{
			printf("%s match successfully!\n", scanner->buffer);
			xml_element* query = xml_element_get_child(scanner->rootElement, "StringValue");
			if(query != NULL)
			{
				printf("StringValue:%s\n", query->text);
			}
			query = xml_element_get_child(scanner->rootElement, "DoubleValue");
			if(query != NULL)
			{
				printf("DoubleValue:%s\n", query->text);
			}
		}
	}
	getchar();
	return 0;
}
