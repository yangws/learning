
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>
#include "xml_def.h"
#include "utils.h"

xml_element* xml_build_element(char* name)
{
	xml_element* element = (xml_element *)ZeroMalloc(sizeof(xml_element));
	element->name = name;
	return element;
}

void xml_element_add_child(xml_element* parent, xml_element* child)
{
	child->parent = parent;

	if(parent->child_list == NULL)
	{
		parent->child_list = (xml_element_list *)ZeroMalloc(sizeof(xml_element_list));
	}
	if(parent->child_list != NULL)
	{
		if(parent->child_list->element == NULL)
		{
			parent->child_list->element = child;
		}
		else
		{
			xml_element_list** siblings = &(parent->child_list->next);
			while(*siblings != NULL)
			{
				siblings = &((*siblings)->next);
			}
			*siblings = (xml_element_list *)ZeroMalloc(sizeof(xml_element_list));
			(*siblings)->element = child;
		}
	}
}

xml_element* xml_element_get_child(xml_element* parent, char* target_name)
{
	if(parent == NULL)
	{
		return NULL;
	}

	xml_element *ret = NULL;

	if(strcmp(parent->name, target_name) == 0)
	{
		return parent;
	}

	xml_element_list *list = parent->child_list;

	while(list != NULL)
	{
		if(list->element != NULL)
		{
			if(strcmp(list->element->name, target_name)==0)
			{
				return list->element;
			}
		}
		list = list->next;
	}

	return NULL;
}