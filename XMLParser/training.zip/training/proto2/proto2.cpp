// proto1.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
#include "proto2.h"


char* test[] = {
	"1a.1b.1c.1d",
	"12.34.56.78",
	"12.0000003.56.78",
	"1.324.56.78",
	"12.56.78",
	"1.2.3.4.5.6.7",
	".",
	"cocos2d",
	"0.1.2.3",
	"99..8.7"
};

bool check_error(IP_SCANNER* scanner)
{
	if(scanner->err != 0)
	{
		printf("%s match error!!!, error: %s at pos %d \n", scanner->buffer, scanner->err_msg, scanner->cur - scanner->buffer);
		return true;
	}
	else 
	{
		
		return false;
	}
}

void set_error(IP_SCANNER* scanner, int err_no, char* err_msg)
{
	if(scanner->err == 0)
	{
		scanner->err = err_no;
		scanner->err_msg = err_msg;
	}
}

bool scanner_walk(IP_SCANNER* scanner)
{
	if(scanner->err != 0)
	{
		return false;
	}
	else
	{
		scanner->cur++;
	}
}

bool is_digit(IP_SCANNER* scanner)
{
	if(*(scanner->cur) >= '0' && *(scanner->cur) <= '9')
	{
		return true;
	}
	else
	{
		return false;
	}
}

int match_digit(IP_SCANNER* scanner)
{
	if(*(scanner->cur) >= '0' && *(scanner->cur) <= '9')
	{
		int ret = *(scanner->cur) - '0';
		scanner_walk(scanner);
		return ret;
	}
	else
	{
		set_error(scanner, ERROR_DIGIT, "digit not match!");
		return -1;
	}
}

void match_number(IP_SCANNER* scanner)
{
	int ret = match_digit(scanner);
	
	while(is_digit(scanner))
	{
		if(ret <= 0)
		{
			set_error(scanner, ERROR_DIGIT, "digit not match!");
			return;
		}
		ret *= 10;
		int d = match_digit(scanner);
		if(( d < 0) || (d > 9))
		{
			set_error(scanner, ERROR_DIGIT, "digit not match!");
			return;
		}
		ret += d;
		if(ret > 255)
		{
			set_error(scanner, ERROR_NUMBER, "number too large");
			return;
		}

	}
}

void match_dot(IP_SCANNER* scanner)
{
	if(*(scanner->cur) == '.')
	{
		scanner_walk(scanner);
		return;
	}
	else 
	{
		set_error(scanner, ERROR_DOT, "dot not match");
		return;
	}
}


void match_end(IP_SCANNER* scanner)
{
	if(*(scanner->cur) == '\0')
	{
		return;
	}
	else
	{
		set_error(scanner, ERROR_END, "end not match");
		return;
	}
}


void init_scanner(IP_SCANNER* scanner, char* buffer)
{
	scanner->buffer = buffer;
	scanner->cur = buffer;
	scanner->err = 0;
}

bool match_ip(IP_SCANNER* scanner)
{
	match_number(scanner);
	match_dot(scanner);
	match_number(scanner);
	match_dot(scanner);
	match_number(scanner);
	match_dot(scanner);
	match_number(scanner);
	match_end(scanner);
	if(check_error(scanner))
	{
		return false;
	}
	printf("%s match successfully\n", scanner->buffer);
	return true;
	//getchar();
	
}
int _tmain(int argc, _TCHAR* argv[])
{
	IP_SCANNER *scanner = (IP_SCANNER *)malloc(sizeof(IP_SCANNER));
	for(int i = 0; i < sizeof(test)/sizeof(test[0]); i ++)
	{
		init_scanner(scanner, test[i]);
		match_ip(scanner);
	}
	getchar();
	return 0;
}
