#ifndef _PROTO2_H_
#define _PROTO2_H_
typedef struct _ip_scanner{
	char* buffer;
	char* cur;
	unsigned int err;
	char *err_msg;
}IP_SCANNER;

#define ERROR_DIGIT 1
#define ERROR_NUMBER 2
#define ERROR_DOT 3
#define ERROR_END 4
#endif