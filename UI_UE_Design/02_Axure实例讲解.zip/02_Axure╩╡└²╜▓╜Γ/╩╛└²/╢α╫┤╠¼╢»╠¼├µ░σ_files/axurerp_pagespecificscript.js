﻿for(var i = 0; i < 25; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u16'] = 'center';document.getElementById('u4_img').tabIndex = 0;
HookHover('u4', false);

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

SetWidgetSelected('u4');
	SetPanelState('u10', 'pd2u10','none','',500,'none','',500);

}
});
document.getElementById('u0_img').tabIndex = 0;
HookHover('u0', false);

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

SetWidgetSelected('u0');
	SetPanelState('u10', 'pd0u10','none','',500,'none','',500);

}
});
document.getElementById('u8_img').tabIndex = 0;
HookHover('u8', false);

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

SetWidgetSelected('u8');
}
});

$axure.eventManager.mouseover('u8', function(e) {
if (!IsTrueMouseOver('u8',e)) return;
if (true) {

	SetPanelVisibility('u22','','fade',500);

}
});

$axure.eventManager.mouseout('u8', function(e) {
if (!IsTrueMouseOut('u8',e)) return;
if (true) {

	SetPanelVisibility('u22','hidden','fade',500);

}
});
gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u14'] = 'center';document.getElementById('u20_img').tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	SetPanelVisibility('u17','toggle','none',500);

}
});
document.getElementById('u6_img').tabIndex = 0;
HookHover('u6', false);

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

SetWidgetSelected('u6');
}
});

$axure.eventManager.mouseover('u6', function(e) {
if (!IsTrueMouseOver('u6',e)) return;
if (true) {

}
});

$axure.eventManager.mouseout('u6', function(e) {
if (!IsTrueMouseOut('u6',e)) return;
if (true) {

}
});
document.getElementById('u2_img').tabIndex = 0;
HookHover('u2', false);

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

SetWidgetSelected('u2');
	SetPanelState('u10', 'pd1u10','none','',500,'none','',500);

}
});
gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u7'] = 'center';