﻿for(var i = 0; i < 22; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u15'] = 'center';document.getElementById('u4_img').tabIndex = 0;
HookHover('u4', false);

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

SetWidgetSelected('u4');
	SetPanelVisibility('u16','','none',500);

	SetPanelVisibility('u10','hidden','none',500);

	SetPanelVisibility('u13','hidden','none',500);

}
});
document.getElementById('u0_img').tabIndex = 0;
HookHover('u0', false);

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

SetWidgetSelected('u0');
	SetPanelVisibility('u10','','none',500);

	SetPanelVisibility('u13','hidden','none',500);

	SetPanelVisibility('u16','hidden','none',500);

}
});
document.getElementById('u8_img').tabIndex = 0;
HookHover('u8', false);

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

SetWidgetSelected('u8');
}
});

$axure.eventManager.mouseover('u8', function(e) {
if (!IsTrueMouseOver('u8',e)) return;
if (true) {

	SetPanelVisibility('u19','','fade',500);

}
});

$axure.eventManager.mouseout('u8', function(e) {
if (!IsTrueMouseOut('u8',e)) return;
if (true) {

	SetPanelVisibility('u19','hidden','fade',500);

}
});
gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u9'] = 'center';document.getElementById('u6_img').tabIndex = 0;
HookHover('u6', false);

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

SetWidgetSelected('u6');
}
});

$axure.eventManager.mouseover('u6', function(e) {
if (!IsTrueMouseOver('u6',e)) return;
if (true) {

}
});

$axure.eventManager.mouseout('u6', function(e) {
if (!IsTrueMouseOut('u6',e)) return;
if (true) {

}
});
document.getElementById('u2_img').tabIndex = 0;
HookHover('u2', false);

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

SetWidgetSelected('u2');
	SetPanelVisibility('u13','','none',500);

	SetPanelVisibility('u10','hidden','none',500);

	SetPanelVisibility('u16','hidden','none',500);

}
});
gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u7'] = 'center';