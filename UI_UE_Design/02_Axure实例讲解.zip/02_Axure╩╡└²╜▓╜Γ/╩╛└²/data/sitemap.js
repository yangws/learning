﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h),_(c,i,e,f,g,j),_(c,k,e,f,g,l,m,[_(c,n,e,f,g,o)]),_(c,p,e,f,g,q)]);}; 
var b="rootNodes",c="pageName",d="多个动态面板",e="type",f="Wireframe",g="url",h="多个动态面板.html",i="多状态动态面板",j="多状态动态面板.html",k="滑动解锁",l="滑动解锁.html",m="children",n="解锁成功",o="解锁成功.html",p="自动切换幻灯片",q="自动切换幻灯片.html";
return _creator();
})();
