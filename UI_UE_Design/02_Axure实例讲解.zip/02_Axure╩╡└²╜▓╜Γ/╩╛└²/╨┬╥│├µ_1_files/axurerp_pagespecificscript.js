﻿for(var i = 0; i < 27; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetGlobalVariableValue('OnLoadVariable', '1');
function waitu2c87223bd52248568c2e55ac99ce4e1b1() {

	SetPanelVisibility('u25','','none',500);
}
setTimeout(waitu2c87223bd52248568c2e55ac99ce4e1b1, 2000);

}

});

widgetIdToShowFunction['u25'] = function() {
var e = windowEvent;

if ((GetGlobalVariableValue('OnLoadVariable')) == ('1')) {

	SetPanelStateNext('u0',true,'fade','',500,'fade','',500);

	SetPanelVisibility('u25','hidden','none',500);

}
else
if ((GetGlobalVariableValue('OnLoadVariable')) == ('0')) {

	SetPanelVisibility('u25','hidden','none',500);

}

}

widgetIdToHideFunction['u25'] = function() {
var e = windowEvent;

if (true) {
function waituc24da4fb3e34424780b33c3f3e3423a81() {

	SetPanelVisibility('u25','','none',500);
}
setTimeout(waituc24da4fb3e34424780b33c3f3e3423a81, 2000);

}

}
gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u4'] = 'center';
$axure.eventManager.mouseover('u26', function(e) {
if (!IsTrueMouseOver('u26',e)) return;
if (true) {

SetGlobalVariableValue('OnLoadVariable', '0');

}
});

$axure.eventManager.mouseout('u26', function(e) {
if (!IsTrueMouseOut('u26',e)) return;
if (true) {

SetGlobalVariableValue('OnLoadVariable', '1');

}
});
gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u20'] = 'center';