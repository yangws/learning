﻿for(var i = 0; i < 19; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});

if (bIE) document.getElementById('u4').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u4'); });
else {
    document.getElementById('u4').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u4'); }, true);
    document.getElementById('u4').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u4'); }, true);
}

widgetIdToDragFunction['u4'] = function() {
var e = windowEvent;

if (IsOver(GetWidgetRectangles('u4'), GetWidgetRectangles('u17'))) {

	MoveWidgetBy('u4',widgetDragInfo.xDelta,0,'none',500);

}

}

widgetIdToDragDropFunction['u4'] = function() {
var e = windowEvent;

if (IsOver(GetWidgetRectangles('u4'), GetWidgetRectangles('u15'))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('解锁成功.html');

}
else
if (true) {

	MoveWidgetTo('u4', GetNum('89'), GetNum('531'),'linear',500);

}

}
gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u18'] = 'center';