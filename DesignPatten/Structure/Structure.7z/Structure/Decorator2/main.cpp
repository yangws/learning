//main.cpp 

#include "Decorator.h" 

#include <iostream> 
using namespace std; 

void DecoratorDemo()
{
	ComponentA* pComponentA = new ComponentA();
	ComponentB* pComponentB = new ComponentB();
	ComponentC* pComponentC = new ComponentC();
	ComponentD* pComponentD = new ComponentD();

	DecoratorD* pDecoratorD = new DecoratorD(pComponentA);
	DecoratorA decoratorA(pDecoratorD);
	string str = decoratorA.GetDescription();
	cout<<"Description: "<<str.c_str()<<endl;
	cout<<"Cost: "<<decoratorA.Cost()<<endl;

	delete pComponentA;
	delete pComponentB;
	delete pComponentC;
	delete pComponentD;
	delete pDecoratorD;
}

int main(int argc,char* argv[]) 
{ 
	DecoratorDemo();
	return 0; 
} 



