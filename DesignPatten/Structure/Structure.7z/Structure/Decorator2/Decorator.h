//Decorator.h 

#ifndef _DECORATOR_H_ 
#define _DECORATOR_H_ 

#include <assert.h>
#include <string>
using namespace std;

class Component
{
public:
	Component(void);
	virtual ~Component(void);
	virtual string GetDescription();
	virtual double Cost() = 0;
};

class Decorator : public Component
{
public:
	Decorator(Component* pComponent);
	~Decorator();
	virtual string GetDescription();
	virtual double Cost();
private:
	Component* m_pComponent;	
};

class ComponentA : public Component
{
public:
	ComponentA();
	~ComponentA();
public:
	virtual string GetDescription();
	virtual double Cost();
};

class ComponentB : public Component
{
public:
	ComponentB();
	~ComponentB();
public:
	virtual string GetDescription();
	virtual double Cost();
};

class ComponentC : public Component
{
public:
	ComponentC();
	~ComponentC();
public:
	virtual string GetDescription();
	virtual double Cost();
};

class ComponentD : public Component
{
public:
	ComponentD();
	~ComponentD();
public:
	virtual string GetDescription();
	virtual double Cost();
};


class DecoratorA : public Decorator
{
public:
	DecoratorA(Component* pComponent);
	~DecoratorA();
public:
	virtual string GetDescription();
	virtual double Cost();
private:
	Component* m_pComponent;
};

class DecoratorB : public Decorator
{
public:
	DecoratorB(Component* pComponent);
	~DecoratorB();
public:
	virtual string GetDescription();
	virtual double Cost();
private:
	Component* m_pComponent;
};

class DecoratorC : public Decorator
{
public:
	DecoratorC(Component* pComponent);
	~DecoratorC()	{	}
public:
	virtual string GetDescription();
	virtual double Cost();
private:
	Component* m_pComponent;
};

class DecoratorD : public Decorator
{
public:
	DecoratorD(Component* pComponent);
	~DecoratorD();
public:
	virtual string GetDescription();
	virtual double Cost();
private:
	Component* m_pComponent;
};

#endif //~_DECORATOR_H_ 

