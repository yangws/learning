//Decorator.cpp 

#include "Decorator.h" 

#include <iostream> 

Component::Component() 
{ 

} 

Component::~Component() 
{ 

} 

string Component::GetDescription()
{
	return "Component";
}

Decorator::Decorator(Component* com) 
{ 
	this->m_pComponent = com; 
} 

Decorator::~Decorator() 
{ 
	delete m_pComponent; 
} 

string Decorator::GetDescription()
{
	return "Decorator";
}

double Decorator::Cost()
{
	return 0;
}

ComponentA::ComponentA() 
{ 

} 

ComponentA::~ComponentA() 
{ 

} 

string ComponentA::GetDescription()
{
	return "ComponentA";
}

double ComponentA::Cost()
{
	return 1.5;
}

ComponentB::ComponentB() 
{ 

} 

ComponentB::~ComponentB() 
{ 

} 
string ComponentB::GetDescription()
{
	return "ComponentB";
}

double ComponentB::Cost()
{
	return 0.99;
}

ComponentC::ComponentC() 
{ 

} 

ComponentC::~ComponentC() 
{ 

} 

string ComponentC::GetDescription()
{
	return "ComponentC";
}
double ComponentC::Cost()
{
	return 0.89;
}

ComponentD::ComponentD() 
{ 

} 

ComponentD::~ComponentD() 
{ 

} 

string ComponentD::GetDescription()
{
	return "ComponentD";
}
double ComponentD::Cost()
{
	return 1.05;
}

DecoratorA::DecoratorA(Component* com) 
{ 
	this->m_pComponent = com; 
} 

DecoratorA::~DecoratorA() 
{ 
	delete m_pComponent; 
} 

string DecoratorA::GetDescription()
{
	return m_pComponent->GetDescription() + ", DecoratorA";
}
double DecoratorA::Cost()
{
	return 0.15 + m_pComponent->Cost();
}

DecoratorB::DecoratorB(Component* com) 
{ 
	this->m_pComponent = com; 
} 

DecoratorB::~DecoratorB() 
{ 
	delete m_pComponent; 
} 
 string DecoratorB::GetDescription()
{
	return m_pComponent->GetDescription() + ", DecoratorB";
}
 double DecoratorB::Cost()
{
	return 0.10 + m_pComponent->Cost();
}

 DecoratorC::DecoratorC(Component* com) 
 { 
	 this->m_pComponent = com; 
 } 
 DecoratorC::~DecoratorC() 
 { 
	 delete m_pComponent; 
 } 
string DecoratorC::GetDescription()
{
	return m_pComponent->GetDescription() + ", DecoratorC";
}
double DecoratorC::Cost()
{
	return 0.10 + m_pComponent->Cost();
}

DecoratorD::DecoratorD(Component* com) 
{ 
	this->m_pComponent = com; 
} 
DecoratorD::~DecoratorD() 
{ 
	delete m_pComponent; 
} 
string DecoratorD::GetDescription()
{
	return m_pComponent->GetDescription() + ", DecoratorD";
}

double DecoratorD::Cost()
{
	return 0.20 + m_pComponent->Cost();
}
