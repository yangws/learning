//main.cpp 

#include "Abstraction.h" 
#include "AbstractionImp.h" 

#include <iostream> 
using namespace std; 

void BridgeDemo()  
{  
	CComputerSystem* pSystem = new CWindows98();  
	CGame* pGame = new CStartCarft(pSystem);  
	pGame->PlayGame();  
	delete pGame;  
	delete pSystem;  
}  

int main(int argc,char* argv[]) 
{ 
	BridgeDemo();
	return 0; 
} 



