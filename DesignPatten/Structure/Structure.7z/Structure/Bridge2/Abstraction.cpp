//Abstraction.cpp 


#include <iostream> 
using namespace std; 
