//Component.cpp 

#include "Component.h" 

Component::Component() 
{ 

} 

Component::~Component() 
{ 

} 

void Component::Add(const Component& com) 
{ 

} 

Component* Component::GetChild(int index) 
{ 
	return 0; 
} 

void Component::Remove(const Component& com) 
{ 

} 

