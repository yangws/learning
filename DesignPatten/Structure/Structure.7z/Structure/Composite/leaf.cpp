//Leaf.cpp 

#include "Leaf.h" 
#include <iostream> 
using namespace std; 

Leaf::Leaf() 
{ 

} 

Leaf::~Leaf() 
{ 
} 

void Leaf::Operation() 
{ 
	cout<<"Leaf operation....."<<endl; 
} 

