var s_ball = "res/ball.png";

var g_ressources = [
    //image
    {src:s_ball}

    //plist

    //fnt

    //tmx

    //bgm

    //effect
];