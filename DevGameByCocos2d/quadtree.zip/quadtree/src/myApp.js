/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2008-2010 Ricardo Quesada
 Copyright (c) 2011      Zynga Inc.

 http://www.cocos2d-x.org

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/
var worldWidth = 800;
var worldHeight = 450;
var NUM_OF_BALLS = 600;
var SIZE_MOD = 7;
var Ball = cc.Class.extend({
    ctor:function(batch){
        //create ball
        var sprt = this.sprt = cc.Sprite.create(s_ball);
        batch.addChild(sprt);

        //random size from 0.25-0.5
        var size = this.size = Math.random()/SIZE_MOD+0.2;
        sprt.setScale(size);
        var radius = this.radius = size*64*0.5;

        //random color
        var color = this.color = cc.c3b(Math.random()*155+100, Math.random()*155+100,Math.random()*155+100);
        sprt.setColor(color);

        //random speed
        var dx = (Math.random()-0.5)*5;
        var dy = (Math.random()-0.5)*5;

        //random direction
        this.dir = Math.random()*360;

        //random position
        var curPos = cc.p(Math.random()*(worldWidth-radius*2)+radius,Math.random()*(worldHeight-radius*2)+radius);
        sprt.setPosition(curPos);
        sprt.lastPos = cc.pAdd(curPos, cc.p(dx,dy));

        //random rotation
        this.rot = Math.random()*360;
        this.sprt.setRotation(this.rot);
        this.rotSpeed = (Math.random()-0.5)*8;
    }

});
var MAXOBJ = 20; //how many obj to hold before splitting
var MAXLVL = 5; // deepest level of quad tree
var Quadtree = cc.Class.extend({
    LVL:0, //current level, 0 is top
    balls:null,
    rect:null,
    nodes:null,
    ctor:function(lvl, rect){
        this.balls = [];
        this.LVL = lvl;
        this.rect = rect;
        this.nodes = [];
    },
    // clear the node and all its child nodes
    clear:function(){
        this.balls = [];
        for(var i = 0; i < this.nodes.length; i++)
        {
            this.nodes[i].clear();
            this.nodes[i] = null;
        }
    },
    // init its 4 child nodes
    split:function(){
        var w = this.rect.width/2;
        var h = this.rect.height/2;
        var x = this.rect.x;
        var y = this.rect.y;
        this.nodes[0] = new Quadtree(this.LVL+1, cc.rect(x+w,y,w,h));
        this.nodes[1] = new Quadtree(this.LVL+1, cc.rect(x,y,w,h));
        this.nodes[2] = new Quadtree(this.LVL+1, cc.rect(x,y+h,w,h));
        this.nodes[3] = new Quadtree(this.LVL+1, cc.rect(x+w,y+h,w,h));
    },
    // determine which node it belongs to
    getIndex:function(ball)
    {
        var pos = ball.sprt.getPosition();
        var radius = ball.radius;
        var index = -1;
        var verticalMid = this.rect.width/2 + this.rect.x;
        var horizontalMid = this.rect.height/2 + this.rect.y;
        var top = (pos.y + radius > horizontalMid);
        var bot = (pos.y - radius < horizontalMid);
        if(pos.x + radius > verticalMid)
        {
            if(top)//left top
            index = 1;
            else if(bot)
            index = 2;
        }
        else if(pos.x - radius < verticalMid)
        {
            if(top)//right top
            index = 0;
            else if(bot)
            index = 3;
        }
        return index;
    },
    insert:function(ball)
    {
        // if i have sub nodes
        if(this.nodes[0])
        {
            var index = this.getIndex(ball);
            if(index !== -1)
            {
                this.nodes[index].insert(ball);
                return;
            }
        }
        this.balls.push(ball);
        if(this.balls.length > MAXOBJ && this.LVL < MAXLVL)
        {
            if(!this.nodes[0]){
                this.split();
            }
            var i = 0;
            while(i<this.balls.length)
            {
                var ball = this.balls[i]
                var idx = this.getIndex(ball);
                if(idx != -1)
                {
                    this.nodes[idx].insert(ball);
                    this.balls.splice(i,1);
                }
                else{
                    i++;
                }
            }
        }
    },
    //get all balls that could collide with that ball
    retrieve:function(listptr, ball){
        var index = this.getIndex(ball);
        if(index !== -1 && this.nodes[0])
        {
            this.nodes[index].retrieve(listptr, ball);
        }
        for(var i = 0; i < this.balls.length; i++)
        {
            listptr.push(this.balls[i]);
        }
        return listptr;

    }
});

var MyLayer = cc.Layer.extend({
    balls:[],
    init:function () {
        this._super();
        var ballBatch = this.batch = cc.SpriteBatchNode.create(s_ball);
        this.addChild(ballBatch);


        for(var i =0; i < NUM_OF_BALLS; i++)
        {
            this.balls.push(new Ball(ballBatch));
        }
        this.scheduleUpdate();

        this.quad = new Quadtree(0, cc.rect(0,0,worldWidth,worldHeight));
    },
    addBalls:function(x){
        for(var i =0; i < x; i++)
        {
            this.balls.push(new Ball(this.batch));
        }
    },
    update:function(){
        /**************** Quad tree *************************/
        this.quad.clear();
        for(var j = 0; j < this.balls.length; j ++)
        {
            this.quad.insert(this.balls[j]);
        }
        for(var i = 0; i < this.balls.length; i ++)
        {
            var ball = this.balls[i];
            //move it by their direction and speed
            var curPos = ball.sprt.getPosition();
            var vel = cc.pSub(ball.sprt.getPosition(), ball.sprt.lastPos);
            var newPos = cc.pAdd(curPos,vel);

            var list = [];
            this.quad.retrieve(list, ball);
            for(var o = 0; o < list.length; o++)
            {
                var otherBall = list[o];
                //check distance
                var dist = cc.pDistance(ball.sprt.getPosition(), otherBall.sprt.getPosition());
                if(dist - ball.radius - otherBall.radius < 0)
                {
                    ball.sprt.lastPos = otherBall.sprt.getPosition();
                    otherBall.sprt.lastPos = curPos;

                }
            }
            //if we are colliding with the world
            if(newPos.x < 0+ball.radius)
            {
                //work out angle of impact
                newPos.x = 0+ball.radius;
                ball.sprt.lastPos = cc.pAdd(newPos, cc.p(vel.x, -vel.y));
            }
            else if(newPos.x > worldWidth-ball.radius)
            {
                newPos.x = worldWidth-ball.radius;
                ball.sprt.lastPos = cc.pAdd(newPos, cc.p(vel.x, -vel.y));
            }
            else if(newPos.y < 0+ball.radius)
            {
                //work out angle of impact
                newPos.y = 0+ball.radius;
                ball.sprt.lastPos = cc.pAdd(newPos, cc.p(-vel.x, vel.y));
            }
            else if(newPos.y > worldHeight-ball.radius)
            {
                newPos.y = worldHeight-ball.radius;
                ball.sprt.lastPos = cc.pAdd(newPos, cc.p(-vel.x, vel.y));
            }
            else{
                ball.sprt.lastPos = curPos;
            }
            ball.sprt.setPosition(newPos);
        }/**/
    },
    updates:function(){
        for(var i=0; i< this.balls.length; i++)
        {
            var ball = this.balls[i];
            if(ball === null)return;
            //rotate the ball
            var newRot = ball.rot+ball.rotSpeed;
            ball.sprt.setRotation(newRot);
            ball.rot = newRot;

            //move it by their direction and speed
            var curPos = ball.sprt.getPosition();
            var vel = cc.pSub(ball.sprt.getPosition(), ball.sprt.lastPos);
            var newPos = cc.pAdd(curPos,vel);

            // if we collide with other ball

            /**************** This is the old way **************/
            for(var o =this.balls.length-1; o>0; o--)
            {
                if(i===o);

                var otherBall = this.balls[o];
                //check distance
                var dist = cc.pDistance(ball.sprt.getPosition(), otherBall.sprt.getPosition());
                if(dist - ball.radius - otherBall.radius < 0)
                {
                    ball.sprt.lastPos = cc.pMidpoint(newPos,otherBall.sprt.getPosition());
                    otherBall.sprt.lastPos = ball.sprt.lastPos;

                }
            }
             /***************************************************/

            //if we are colliding with the world
            if(newPos.x < 0+ball.radius)
            {
                //work out angle of impact
                newPos.x = 0+ball.radius;
                ball.sprt.lastPos = cc.pAdd(newPos, cc.p(vel.x, -vel.y));
            }
            else if(newPos.x > worldWidth-ball.radius)
            {
                newPos.x = worldWidth-ball.radius;
                ball.sprt.lastPos = cc.pAdd(newPos, cc.p(vel.x, -vel.y));
            }
            else if(newPos.y < 0+ball.radius)
            {
                //work out angle of impact
                newPos.y = 0+ball.radius;
                ball.sprt.lastPos = cc.pAdd(newPos, cc.p(-vel.x, vel.y));
            }
            else if(newPos.y > worldHeight-ball.radius)
            {
                newPos.y = worldHeight-ball.radius;
                ball.sprt.lastPos = cc.pAdd(newPos, cc.p(-vel.x, vel.y));
            }
            else{
                ball.sprt.lastPos = curPos;
            }
            ball.sprt.setPosition(newPos);
        }
    }
});

var MyScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new MyLayer();
        window.layer = layer;
        this.addChild(layer);
        layer.init();
    }
});
