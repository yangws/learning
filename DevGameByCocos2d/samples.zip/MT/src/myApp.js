/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2008-2010 Ricardo Quesada
 Copyright (c) 2011      Zynga Inc.

 http://www.cocos2d-x.org

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/
var SwingBackForth = cc.EaseBackInOut.extend({
    update:function (time1) {
        var overshoot = 1.70158 * 1.525 * 150;

        time1 = time1 * 2;
        if (time1 < 1) {
            this._other.update((time1 * time1 * ((overshoot + 1) * time1 - overshoot)) / 2);
        } else {
            time1 = time1 - 2;
            this._other.update((time1 * time1 * ((overshoot + 1) * time1 + overshoot)) / 2 + 1);
        }
    }
});
SwingBackForth.create = function (action) {
    var ret = new SwingBackForth();
    if (ret) {
        ret.initWithAction(action);
    }
    return ret;
};

var MyLayer = cc.Layer.extend({
    isMouseDown:false,
    helloImg:null,
    helloLabel:null,
    circle:null,
    sprite:null,

    init:function () {
        this._super();
        var VS = cc.Director.getInstance().getVisibleSize();
        var mt = cc.Sprite.create(s_mt);
        this.addChild(mt);
        mt.setPosition(cc.p(VS.width/2-300, VS.height/2));
        this.setMouseEnabled(true);
        this.mt = mt;
    },
    onMouseDown:function(){
        this.mt.setRotation(-1);

        // Swing back and forth
        var action1 = cc.RotateTo.create(0.5, 0);
        var action1Eased = SwingBackForth.create(action1);
        this.mt.runAction(action1Eased);

        // a small jump
        var action2 = cc.JumpTo.create(0.3, this.mt.getPosition(), 40,1);
        this.mt.runAction(action2);/**/

        // a slash crescent
        var slash = cc.Sprite.create(s_slash);
        slash.setPosition(this.mt.getPosition());
        this.addChild(slash);/**/

        // crescent should move
        var action3 = cc.MoveBy.create(0.7, cc.p(500,0));
        //slash.runAction(action3);/**/

        // crescent should be delayed ***Tip to self, remove previous action
        var action3Delayed = cc.Sequence.create(cc.DelayTime.create(0.2), action3, cc.CallFunc.create(this.removeSlash, this, slash));
        //slash.runAction(action3Delayed);/**/

        // crescent display should be delayed too
        slash.setOpacity(0);
        var action4 = cc.FadeIn.create(0.2);
        var action4Delayed = cc.Sequence.create(cc.DelayTime.create(0.2), action4);
        //slash.runAction(action4Delayed);/**/

        //combine actions ***tip to self, comment out previous actions
        var action5 = cc.Spawn.create(action3, action4);
        var slashSequence = cc.Sequence.create(cc.DelayTime.create(0.2), action5, cc.CallFunc.create(this.removeSlash, this, slash));/**/
        slash.runAction(slashSequence);
    },
    removeSlash:function(x){
        this.removeChild(x);
    }
});

var MyScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new MyLayer();
        this.addChild(layer);
        layer.init();
    }
});
