var s_mt = "dainiu.png";
var s_slash = "slash.png";
var s_hurt = "res/hurt.wav";

var g_ressources = [
    //image
    {src:s_mt},
    {src:s_slash},
    {src:s_hurt}

    //plist

    //fnt

    //tmx

    //bgm

    //effect
];