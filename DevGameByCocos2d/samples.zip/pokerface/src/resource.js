var s_cardBack = "cardBack.png";
var s_pokerFace = "pokerface.png";

var g_ressources = [
    //image
    {src:s_cardBack},
    {src:s_pokerFace}

    //plist

    //fnt

    //tmx

    //bgm

    //effect
];