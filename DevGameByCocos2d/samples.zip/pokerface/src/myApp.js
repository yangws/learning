/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2008-2010 Ricardo Quesada
 Copyright (c) 2011      Zynga Inc.

 http://www.cocos2d-x.org

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/

var MyLayer = cc.Layer.extend({
    isMouseDown:false,
    helloImg:null,
    helloLabel:null,
    circle:null,
    sprite:null,

    init:function () {
        this._super();
        var cardBack = cc.Sprite.create(s_cardBack);
        var pokerFace = cc.Sprite.create(s_pokerFace);
        var VS = cc.Director.getInstance().getVisibleSize();
        pokerFace.setPosition(cc.p(cardBack.getContentSize().width/2, cardBack.getContentSize().height/2));
        this.setMouseEnabled(true);
        this.card = cardBack;
        this.face = pokerFace;
        cardBack.setVertexZ(0);
        pokerFace.setVertexZ(50);
        pokerFace.setScale(0.87);
        cardBack.addChild(pokerFace);
        var center = cc.p(VS.width/2, VS.height/2);
        cardBack.setPosition(center);
        this.addChild(cardBack);

    },
    onMouseDown:function(){
        // make the card stand up          (time, radius, dRadius, angleZ, dAngleZ, angleX, dAngleX)
        //var action1 = cc.OrbitCamera.create(0.3, 1, 0, 0, 45, 90,0);
        // make the face stand up

        // make the card twist around
        var action1 = cc.OrbitCamera.create(          0.3, 1,0, 0, 35, 90,  0);
        var turnRightFromMid = cc.OrbitCamera.create( 0.2, 1,0, 35, 0, 90,  15);
        var turnLeftFromRight = cc.OrbitCamera.create(0.4, 1,0, 35, 0, 105, -30);

        var turnRightFromMidEased = cc.EaseSineInOut.create(turnRightFromMid);
        var turnLeftFromRightEased = cc.EaseSineInOut.create(turnLeftFromRight);
        var turnMidFromRightEased = turnRightFromMidEased.reverse();
        var turnRightFromLeftEased = turnLeftFromRightEased.reverse();

        var repeat = cc.Repeat.create(cc.Sequence.create(turnLeftFromRightEased,turnRightFromLeftEased),3);
        var twist = cc.Sequence.create(action1, cc.DelayTime.create(0.5), turnRightFromMidEased,repeat,turnMidFromRightEased, action1.reverse());
        this.card.runAction(twist);
    }
});

var MyScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new MyLayer();
        this.addChild(layer);
        layer.init();
    }
});
