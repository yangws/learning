var s_droplet = "droplet.png";

var g_ressources = [
    //image
    {src:s_droplet}

    //plist

    //fnt

    //tmx

    //bgm

    //effect
];