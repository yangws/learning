/****************************************************************************
 Copyright (c) 2010-2012 cocos2d-x.org
 Copyright (c) 2008-2010 Ricardo Quesada
 Copyright (c) 2011      Zynga Inc.

 http://www.cocos2d-x.org

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/
var COLLISION_TYPE_FLOOR = 2;
var COLLISION_TYPE_INNERWALL = 3;
var COLLISION_TYPE_WATER = 4;
var GRAVITY = 700;
var BALL_RADIUS = 6;
var DROPLET_SIZE = 4;
var ALPHA_CUTOFF = 0.2;
var DROPLET_OPACITY = 255;
var COLLISION_BIAS = 0.000001;

var Mode = "liquid";

var MyLayer = cc.Layer.extend({
    isMouseDown:false,
    helloImg:null,
    helloLabel:null,
    circle:null,
    sprite:null,

    init:function () {
        this._super();
        this.shapesToRemove = [];
        this.initPhysics();
        this.createWorldBoundary();
        this.setuplevel();
        this.scheduleUpdate();
        this.addLotsOfBalls();
        this.setShader();
    },
    setShader:function(){
        //gl.enable( gl.DEPTH_TEST );

        var alphaTestShader = cc.ShaderCache.getInstance().getProgram("ShaderPositionTextureColorAlphaTest");
        var glprogram = alphaTestShader.getProgram();
        var alphaValueLocation = gl.getUniformLocation(glprogram, cc.UNIFORM_ALPHA_TEST_VALUE_S);

        // set alpha test value
        // NOTE: alpha test shader is hard-coded to use the equivalent of a glAlphaFunc(GL_GREATER) comparison
        gl.useProgram( glprogram );
        alphaTestShader.setUniformLocationF32(alphaValueLocation, ALPHA_CUTOFF);
        this.RT.getSprite().setShaderProgram(alphaTestShader);
        this.RT.getSprite().setColor(cc.c3b(85,233,255));
        //this.RT.setShaderProgram(alphaTestShader);
    },
    initPhysics:function(){
        this._space = new cp.Space();
        this._space.iterations = 1;
        // Gravity
        this._space.gravity = cp.v(0, -GRAVITY);
        this._space.collisionBias = COLLISION_BIAS; // makes balls pushes more
    },
    createWorldBoundary: function(){
        var staticBody = this._space.staticBody;

        var visibleSize = cc.Director.getInstance().getVisibleSize();
        this.VS = visibleSize;
        var x = 0;
        var y = 0;
        var w = visibleSize.width;
        var h = visibleSize.height;
        var walls = [new cp.SegmentShape(staticBody, cp.v(x, y), cp.v(w, y), 10), // bottom
            new cp.SegmentShape(staticBody, cp.v(x, h), cp.v(w, h), 10), // top
            new cp.SegmentShape(staticBody, cp.v(x, y), cp.v(x, h), 10), // left
            new cp.SegmentShape(staticBody, cp.v(w, y), cp.v(w, h), 10)      // right
        ];
        for (var i = 0; i < walls.length; i++) {
            var wall = walls[i];
            wall.setElasticity(0);
            wall.setFriction(0);
            wall.setCollisionType(COLLISION_TYPE_FLOOR);
            this._space.addStaticShape(wall);
        }

        var leftWall = new cp.SegmentShape(staticBody, cp.v(visibleSize.width/2-60,visibleSize.height/2+100), cp.v(visibleSize.width/2-60, visibleSize.height/2-100), 15);
        var rightWall = new cp.SegmentShape(staticBody, cp.v(visibleSize.width/2+60,visibleSize.height/2+100), cp.v(visibleSize.width/2+60, visibleSize.height/2-50), 15);
        var bottomWall = new cp.SegmentShape(staticBody, cp.v(visibleSize.width/2+60,visibleSize.height/2-100), cp.v(visibleSize.width/2-60, visibleSize.height/2-100), 15);

        var innerWalls = [leftWall, rightWall, bottomWall];
        for(i = 0; i < innerWalls.length; i++)
        {
            var wall = innerWalls[i];
            wall.setElasticity(0);
            wall.setFriction(0);
            wall.setCollisionType(COLLISION_TYPE_INNERWALL);
            this._space.addStaticShape(wall);
        }
    },
    setuplevel:function(){
        this.debugNode = cc.PhysicsDebugNode.create(this._space);
        this.addChild(this.debugNode);
        window.physics = this.debugNode;
        var winsize = cc.Director.getInstance().getWinSize();
        this.RT = cc.RenderTexture.create(winsize.width, winsize.height);
        this.RT.setPosition(winsize.width / 2, winsize.height / 2);

        this.batch = cc.SpriteBatchNode.create(s_droplet, 100);
        this.batch.retain();
        if(Mode === "liquid")
        {
            this.addChild(this.RT);
            this.debugNode.setVisible(false);
        }
        else if(Mode === "smoke")
        {
            this.addChild(this.batch);
            this.debugNode.setVisible(false);
        }

        this.setTouchEnabled(true);
        this.setMouseEnabled(true);
        this._space.addCollisionHandler(COLLISION_TYPE_FLOOR, COLLISION_TYPE_WATER, this.onWaterHitFloor.bind(this), null, null, null);
        var wall1 = cc.LayerColor.create(cc.c4b(255,255,255,255), 20, 200);
        this.addChild(wall1);
        wall1.ignoreAnchorPointForPosition(false);
        wall1.setPosition(cc.p(this.VS.width/2-60,this.VS.height/2));
        var wall2 = cc.LayerColor.create(cc.c4b(255,255,255,255), 20, 160);
        this.addChild(wall2);
        wall2.ignoreAnchorPointForPosition(false);
        wall2.setPosition(cc.p(this.VS.width/2+60,this.VS.height/2+20));
        var wall2 = cc.LayerColor.create(cc.c4b(255,255,255,255), 120, 20);
        this.addChild(wall2);
        wall2.ignoreAnchorPointForPosition(false);
        wall2.setPosition(cc.p(this.VS.width/2,this.VS.height/2-100));
    },
    addBall:function(){
        var x = this.VS.width/2 + (Math.random()-0.5)*10;
        var y = this.VS.height - 30;
        var sprite = cc.PhysicsSprite.create(s_droplet);
        sprite.setScale(DROPLET_SIZE);
        sprite.setOpacity(DROPLET_OPACITY);

        var body = this._space.addBody(new cp.Body(1, cp.momentForCircle(1, BALL_RADIUS,0,cp.v(0,0))));
        body.setPos(cp.v(x, y));
        var shape = this._space.addShape(new cp.CircleShape(body, BALL_RADIUS, cp.v(0,0)));
        shape.setElasticity(0.0);
        shape.setFriction(0.0);
        shape.setCollisionType(COLLISION_TYPE_WATER);
        sprite.setBody(body);
        body.sprite = sprite;
        this.batch.addChild(sprite);
    },
    onMouseDown:function(){
        console.log("adding balls");
        this.addBall();
    },
    update:function(){
        this._space.step(1/60);
        if(Mode==="liquid")
        {
            //this.RT.beginWithClear(0,0,0,0);
            this.RT.beginWithClear(85,233,255,0);
            this.batch.setVisible(true);
            this.batch.visit();
            this.batch.setVisible(false);
            this.RT.end();
        }
    },
    cleanBalls:function(){
        var toRemove = this.shapesToRemove;
        if(toRemove.length)
        {
            for(var i =0; i < toRemove.length; i++)
            {
                var body = toRemove[i].getBody();
                this.batch.removeChild(body.sprite)
                this._space.removeBody(body);
                this._space.removeShape(toRemove[i]);
            }
            console.log("removed "+ i + " balls, shapes : "+ this._space.staticShapes.length+" bodies : "+ this._space.bodies.length);
            this.shapesToRemove = [];
        }
    },
    addLotsOfBalls:function(){
        this.getScheduler().scheduleCallbackForTarget(this, this.addBall, 0.03);
        this.getScheduler().scheduleCallbackForTarget(this, this.cleanBalls, 0.3);
    },
    onWaterHitFloor:function(a){
        this.shapesToRemove.push(a.getB());
    }
});

var MyScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new MyLayer();
        this.addChild(layer);
        layer.init();
    }
});
